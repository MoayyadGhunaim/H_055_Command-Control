function [Labels clusterLabel sizeRank] = clusteringV2(currentLon, currentLat, distanceThreshold)
%%%% This is the verified version
%%%%

% function [Labels] = clusteringV2(currentLon, currentLat, distanceThreshold)

% calculate distance matrix:
numOfNodes = length(currentLon);
randNode = ceil(rand*numOfNodes);
distMat = inf(numOfNodes,numOfNodes);
for i=1:numOfNodes
    for j=1:numOfNodes
        dist = sqrt( (currentLon(i)-currentLon(j))^2 + (currentLat(i)-currentLat(j))^2 );
        if dist <= distanceThreshold
            distMat(i,j) = dist;
        end
    end
end

%     if t==21
%         pause(1)
%     end

G = double(distMat<Inf);        % initialize group matrix to 1s and 0s
for i=1:floor(numOfNodes/2)-1
    G=G*G;
    G(G > 0) = 1;
end

L = zeros(1,numOfNodes);  % initialize labels to infinity
clusterLabel=1;
row=1;

while ~isempty(find(L==0))   % while there is at least one label equal to 0
    if L(row)==0      % if this node has not been labeled yet
        referenceRow = G(row,:);
        L(row)   = clusterLabel;
        G(row,:) = referenceRow * L(row);
        clusterLabel = clusterLabel + 1;
        label = L(row);
        
        
        for rr=row+1:numOfNodes  % compare referenceRow with all next rows
            if L(rr)==0
                currentRow = G(rr,:);
                p = referenceRow * currentRow';
                if p~=0    % if there is overlap between this row and referenceRow
                    G(rr,:) = currentRow*label;
                    L(rr) = label;
                end
            end
        end
    end
    row=row+1;
end

Labels = L;

u = unique(Labels);
cnt=zeros(1,length(u));

for ui=1:length(u)
    cnt(ui)=sum(Labels==u(ui));
end

CNT = cnt;
rnkCnt=1;
rank=zeros(1,length(u));
for ri=1:length(u)
    [~,maxind] = max(CNT);
    rank(maxind) = rnkCnt;
    rnkCnt = rnkCnt+1;
    CNT(maxind)=-1;
end

clusterLabel = zeros(1,numOfNodes);
sizeRank = zeros(1,numOfNodes);

for ui=1:length(u)
    clusterLabel(Labels==u(ui)) = cnt(ui);
    sizeRank(Labels==u(ui)) = rank(ui);
end




%     clusterLabel sizeRank