function [Labels groupCount sizeRank] = clusteringV2(currentLon, currentLat, distanceThreshold)
% function [Labels] = clusteringV2(currentLon, currentLat, distanceThreshold)

% calculate distance matrix:
    numOfNodes = length(currentLon);
    randNode = ceil(rand*numOfNodes);
    distMat = inf(numOfNodes,numOfNodes);
    for i=1:numOfNodes
        for j=1:numOfNodes
            dist = sqrt( (currentLon(i)-currentLon(j))^2 + (currentLat(i)-currentLat(j))^2 );
            if dist <= distanceThreshold
                distMat(i,j) = dist;
            end
        end
    end
    
    %     if t==21
    %         pause(1)
    %     end
    
    G = double(distMat<Inf);        % initialize group matrix to 1s and 0s
    for countG = 1 : log10(numOfNodes)
        G = G^10;
        G(G > 0) = 1;
    end
    L = inf(1,numOfNodes);  % initialize labels to infinity
    groupCount=1;
    row=1;
    
    while ~isempty(find(L==inf))   % while there is at least one label equal to infinity
%     while row<=numOfNodes   % while there is at leat one label equal to 0
       
%         if row==35
%             pause(0.5)
%         end
        
        referenceRow = G(row,:);
        subset = L(logical(referenceRow));
        minLabel = min( subset );
%         if L(row)==0
        if isinf(minLabel) %|| minLabel==0
            L(row)   = groupCount;
            G(row,:) = referenceRow * L(row);
            groupCount = groupCount + 1;
        else
            L(row) = minLabel;
        end
        
        if isinf(L(row))
            pause(0.5)
        end
        
        label = L(row);
%         label = minLabel;
        
        
        for rr=row+1:numOfNodes  % compare referenceRow with all next rows
            currentRow = G(rr,:);
            p = referenceRow * currentRow';
            if isinf(L(rr)) && p~=0    % if this row has not been labeled befor AND there is overlap between this row and referenceRow
                G(rr,:) = currentRow*label;
                L(rr) = label;
            end
        end
        row=row+1;
    end
    
    Labels = L;
    
    u = unique(Labels);
    cnt=zeros(1,length(u));
    
    for ui=1:length(u)
        cnt(ui)=sum(Labels==u(ui));
    end
    
    CNT = cnt;
    rnkCnt=1;
    rank=zeros(1,length(u));
    for ri=1:length(u)
        [~,maxind] = max(CNT);
        rank(maxind) = rnkCnt;
        rnkCnt = rnkCnt+1;
        CNT(maxind)=-1;
    end
    
    groupCount = zeros(1,numOfNodes);
    sizeRank = zeros(1,numOfNodes);
    
    for ui=1:length(u)
        groupCount(Labels==u(ui)) = cnt(ui);
        sizeRank(Labels==u(ui)) = rank(ui);
    end
    
    
    
    
%     groupCount sizeRank