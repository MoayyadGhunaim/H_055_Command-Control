

clc
clear all

web_folder = '..\Web_Data\';
textfile = [web_folder 'report.txt'];

site(1).location(1).time(1).data = 3;
site(1).location(1).time(2).data = 3;
site(1).location(1).time(3).data = 3;

site(1).location(2).time(1).data = 5;
site(1).location(2).time(2).data = 5;
site(1).location(2).time(3).data = 5;

site(1).location(3).time(1).data = 3;
site(1).location(3).time(2).data = 4;
site(1).location(3).time(3).data = 3;

site(1).location(4).time(1).data = 6;
site(1).location(4).time(2).data = 6;
site(1).location(4).time(3).data = 6;

site(1).location(1).circle = [320-90,380, 20];
site(1).location(2).circle = [310,210, 20];
site(1).location(3).circle = [230-90,350, 20];
site(1).location(4).circle = [160-90,245, 20];
site(1).image_name = '..\images\maps\haram.bmp';


site(2).location(1).time(1).data = 3;
site(2).location(1).time(2).data = 3;
site(2).location(1).time(3).data = 3;

site(2).location(2).time(1).data = 5;
site(2).location(2).time(2).data = 5;
site(2).location(2).time(3).data = 5;

site(2).location(3).time(1).data = 3;
site(2).location(3).time(2).data = 4;
site(2).location(3).time(3).data = 5;

site(2).location(4).time(1).data = 3;
site(2).location(4).time(2).data = 3;
site(2).location(4).time(3).data = 3;

site(2).location(1).circle = [470,360, 50];
site(2).location(2).circle = [280,300, 30];
site(2).location(3).circle = [180,230, 30];
site(2).location(4).circle = [110,150, 30];
site(2).image_name = '..\images\maps\mina.bmp';

for site_i=1:2
    for time_i=1:2
        pause(1);
        I = imread(site(site_i).image_name);
        for location_i=1:4
            customData = site(site_i).location(location_i).time(time_i).data;
            [congestion_status, alarm_color]= assiss_congestion(customData);
            if isempty(alarm_color) || isempty(congestion_status), error('empty output from assiss_congestion'); end
%             ftxt = fopen(textfile, 'w'); fprintf(ftxt, '%s\n', congestion_status);   % update the web text file
            
            I =insertShape(I, 'FilledCircle', site(site_i).location(location_i).circle, 'color', alarm_color);
            
            
            inputDataImageName = ['..\images\_Data_' num2str(customData) '.png'];   % source detailed image --- use imread/imwrite
            IN = imread(inputDataImageName);
            imwrite(IN, [web_folder 'detailed_image_location_' num2str(location_i) '.png']);
        end
        imwrite(I, [web_folder 'site_' num2str(site_i) '.png']);
    end
end



