Hajj Hackathon
Team H55

This is a work in progress for our code. In this code the following features are working:
1. crowd congestion assisment
2. status display on map 