clear all
margin=5;

lon = []; lat=[];
fig = figure(10);
hold on;
ax=gca;
ax.Position=[0,0,1,1];
xlim([0 100]);
ylim([0 100]);
x=0; y=0;

cnt = 0;
for i=1:10000000
    % xlim([0 100])
    % ylim([0 100])
    [x,y] = ginput;
    cnt=cnt+1;
    save(['Hackathon_data\Hdata_' num2str(cnt)], 'lon', 'lat');
    plot(x, y , 'o', 'linewidth', 1, 'color', 'k','MarkerFaceColor', 'k' );
    print(fig, '-dpng', ['Hackathon_data\Hdata_' num2str(cnt) '.png']);
    lon = [lon x'];
    lat = [lat y'];
    
    currentLon = lon;
    currentLat = lat;
%     minLon = min(lon);
    
%     minLat = min(lat);
%     maxLon = max(lon);
%     maxLat = max(lat);
    
    hold on
    
end