

N=10:1000;
O1 = N.^floor(N/2);
m=ceil(log2( floor(N/2) ));
O2 = N.^m;

p1=loglog(N, O1, 'k', 'linewidth', 2);
% plot(N, log10(O1), 'k', 'linewidth', 2)
grid on
hold on
p2=loglog(N, O2, 'r', 'linewidth', 2);
% plot(N, log10(O2), 'r', 'linewidth', 2)
xlabel('number of nodes (N)');
ylabel('computational complixity (O)');
legend([p1, p2], 'ordinary method', 'proposed method', 'location', 'northwest');