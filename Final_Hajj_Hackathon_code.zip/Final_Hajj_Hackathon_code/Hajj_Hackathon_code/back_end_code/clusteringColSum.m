function [Labels, groupCount, sizeRank] = clusteringColSum(currentLon, currentLat, distanceThreshold)
% function [Labels] = clusteringV2(currentLon, currentLat, distanceThreshold)

% calculate distance matrix:
    numOfNodes = length(currentLon);
    randNode = ceil(rand*numOfNodes);
    distMat = inf(numOfNodes,numOfNodes);
    for i=1:numOfNodes
        for j=1:numOfNodes
            dist = sqrt( (currentLon(i)-currentLon(j))^2 + (currentLat(i)-currentLat(j))^2 );
            if dist <= distanceThreshold
                distMat(i,j) = dist;
            end
        end
    end
    
    
    G = double(distMat<Inf);        % initialize group matrix to 1s and 0s
    for i=1:floor(numOfNodes/2)-1
        G=G*G;
        G(G > 0) = 1;
    end

    S = sum(G);
    clusterLabel=1;
    while ~isempty(S(S>0))
        mx = max(S);
        pos = S==mx;
        S(pos)=-clusterLabel;
        groupCount(clusterLabel)=mx;
        sizeRank(pos)=clusterLabel;
        clusterLabel=clusterLabel+1;
    end
    
    Labels = -S;
    
    
    