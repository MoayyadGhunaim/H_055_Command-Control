




function [congestion_status, alarm_color]= assiss_congestion(customData)

% site1.time1.data = 3;
% r=0.0010;
% r=7;
congestion_status = '';
alarm_color = [];
qth = 20;
r_list = [7, 2];
Ver=2;
% customData = 6;
color = [1 0 0; 0 1 0; 0 0 1; 1 0 1; 0 1 1 ; 1 0.7 0.7; .5 .5 .5; 0.7 0.7 0.7; 1 0.5 0; 0 1 0.5];
blackcolor=zeros(1000,3);
color = [color; blackcolor];
im=imread('map.png');

% site A: Haram
site_A_location_1 = [320-90,380, 20];
site_A_location_2 = [230-90,350, 20];
site_A_location_3 = [230-90,350, 20];
site_A_location_4 = [160-90,245, 20];

% site B: Mina
site_B_location_1 = [470,360, 50];
site_B_location_2 = [280,300, 30];
site_B_location_3 = [180,230, 30];
site_B_location_4 = [110,150, 30];

are_there_clusters_after_the_pass = [];

% n=1:100;

if customData==1
    load TEST_DATA_01;
    %     r=7;
elseif customData==2
    load TEST_DATA_02;
    %     r=7;
elseif customData==3
    load TEST_DATA_03;
    %     r=7;
elseif customData==4
    load TEST_DATA_04;
    %     r=7;
elseif customData==5
    load TEST_DATA_05;
    %     r=7.6;
elseif customData==6
    load TEST_DATA_06;
    %     r=7;
elseif customData==7
    load TEST_DATA_07;
    %     r=7;
elseif customData==10   % use Hackathon data
    xx = [];
    yy = [];
    for Hdata_i = 1:25  % in the Hajj Hackathon we created 25 sets of data
        xx = lat;
        yy = lon;
    end
else
    r=0.00080;
    f=fopen('..\Apr05_v1.csv');
    if f<0, error('no file\n'); end;
    lat=[];
    lon=[];
    s=fgetl(f);
    while ~feof(f)
        s=fgetl(f);
        ind=find(s=='@');
        x=s(ind(1)+1:ind(2)-1);
        x=str2num(x);
        lat=[lat; x];
        x=s(ind(2)+1:ind(3)-1);
        x=str2num(x);
        lon=[lon; x];
    end
    
    clear h;
    n=3;
    h(1:n)=1/n;
    
    latTmp = lat;
    lonTmp = lon;
    
    for i=1:size(lat,2)
        latsm=lat(:,i);
        latsm = conv(latsm, h);
        latsm(1:n-1)=[];
        latsm(end-n-1+1:end)=[];
        lat1(:,i)=latsm;
    end
    
    for i=1:size(lon,2)
        lonsm=lon(:,i);
        lonsm = conv(lonsm, h);
        lonsm(1:n-1)=[];
        lonsm(end-n-1+1:end)=[];
        lon1(:,i)=lonsm;
    end
    
    lat=lat1;
    lon=lon1;
    
end

maxLat=max(lat(:));
minLat=min(lat(:));

maxLon=max(lon(:));
minLon=min(lon(:));

numOfNodes = size(lat,2);
del = false(1,numOfNodes);   % intialize to zeros

for pass_num = 1:2  % cluster qualification pass
    r = r_list(pass_num);
    lon(:,del)=[];   % delete small clusters
    lat(:,del)=[];   % delete small clusters
    
    for t=1:size(lat,1)
        
        currentLon = lon(t,:);
        currentLat = lat(t,:);
        
        %%%%%%%%%%%%%%%%%%%%%%% algorithm at time t %%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if Ver==1
            [Labels, groupCount, sizeRank] = clusteringV1(currentLon, currentLat, r);  % not needed any more
        elseif Ver==2
            [Labels, groupCount, sizeRank] = clusteringV2(currentLon, currentLat, r);
        elseif Ver==3
            [Labels, groupCount, sizeRank] = clusteringColSum(currentLon, currentLat, r);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%% find largest group %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        hold off
        
        if customData==8,
            margin=0.0005;
        else
            margin=5;
            
        end
        
        close all;
        
        del = groupCount < qth;
        
        Labels(:,del) = [];
        groupCount(:,del) = [];
        sizeRank(:,del) = [];
        currentLon(:,del) = [];
        currentLat(:,del) = [];
        numOfNodes = size(currentLat,2);
        
        are_there_clusters_after_the_pass = [are_there_clusters_after_the_pass ~isempty(Labels)]
        
        % plot inout data (unprocssed black dots)
        
        %         fig_black = figure(10);
        %         plot(currentLon, currentLat , 'o', 'linewidth', 1, 'color', 'k','MarkerFaceColor', 'k' );
        %         ax=gca;
        %         ax.Position=[0,0,1,1];
        %         xlim([minLon-margin maxLon+margin ]);
        %         ylim([minLat-margin maxLat+margin ]);
        %
        %         % plot colore-coded data
        %         fig_colored = figure(3);
        %         for p=1:numOfNodes
        %             %         if p==4, continue; end;
        %             hh=plot(currentLon(p), currentLat(p) , 'o', 'linewidth', 1, 'color', color( sizeRank(p), : ));
        %             set(hh,'MarkerFaceColor', color( sizeRank(p), : ) );
        %             ax=gca;
        %             ax.Position=[0,0,1,1];
        %             if customData==8,
        %                 text(46.6425, 24.7315, ['t = ' (num2str(t-1))], 'fontsize', 18);%, 'fontweight', 'bold');
        %             end
        %             xlim([minLon-margin maxLon+margin ]);
        %             ylim([minLat-margin maxLat+margin ]);
        %             hold on;
        %         end
        %         if customData==8, k = waitforbuttonpress; while k~=0; end; end
        %         print(fig_colored, '-dpng', ['..\images\' num2str(t) '.png'])
        %         print(fig_black, '-dpng', ['..\images\' num2str(t) '_input.png'])
        %         print(fig_colored, '-dpng', ['..\images\_Data_' num2str(customData) '.png'])
        pins=unique(sizeRank);
        cnt=zeros(1,length(pins));
        for hhh=1:max(pins)
            cnt(hhh)=sum(sizeRank==pins(hhh));
            fprintf('Cluster#%i = %i nodes\n', pins(hhh), cnt(hhh));
        end
        
    end
    
end

if     sum(are_there_clusters_after_the_pass) == 0,
    congestion_status = 'No Congestion';
    alarm_color = [0, 255, 0];
elseif sum(are_there_clusters_after_the_pass) == 1,
    congestion_status = 'Moderate Congestion';
    alarm_color = [255,255,0];
elseif sum(are_there_clusters_after_the_pass) == 2,
    congestion_status = 'Severe Congestion';
    alarm_color = [255, 0, 0];
    
end;
