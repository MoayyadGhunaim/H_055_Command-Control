

clc
clear all

web_folder = '..\Web_Data\';
% textfile = [web_folder 'report.txt'];



site(1).location(1).data_id = 6;
site(1).location(2).data_id = 5;
site(1).location(3).data_id = 5;
site(1).location(4).data_id = 5;

site(1).location(1).circle = [320-90,380, 20];
site(1).location(2).circle = [310,210, 20];
site(1).location(3).circle = [230-90,350, 20];
site(1).location(4).circle = [160-90,245, 20];
site(1).image_name = '..\images\maps\haram.bmp';


site(2).location(1).data_id = 3;
site(2).location(2).data_id = 5;
site(2).location(3).data_id = 3;
site(2).location(4).data_id = 3;

site(2).location(1).circle = [300,350, 50];
site(2).location(2).circle = [200,200, 30];
site(2).location(3).circle = [120,300, 30];
site(2).location(4).circle = [50,250, 30];
site(2).image_name = '..\images\maps\mina.bmp';

% get data for each location
for site_data_i = 1:length(site)
    for loc_data_i = 1:length(site(site_data_i).location)
        if loc_data_i<=3
            if site(site_data_i).location(loc_data_i).data_id ==1,     load TEST_DATA_01;
            elseif site(site_data_i).location(loc_data_i).data_id ==2,     load TEST_DATA_02;
            elseif site(site_data_i).location(loc_data_i).data_id ==3,     load TEST_DATA_03;
            elseif site(site_data_i).location(loc_data_i).data_id ==4,     load TEST_DATA_04;
            elseif site(site_data_i).location(loc_data_i).data_id ==5,     load TEST_DATA_05;
            elseif site(site_data_i).location(loc_data_i).data_id ==6,     load TEST_DATA_06;
            elseif site(site_data_i).location(loc_data_i).data_id ==7,     load TEST_DATA_07;
            else
                % car data
            end
            site(site_data_i).location(loc_data_i).dataX{1}= lat;
            site(site_data_i).location(loc_data_i).dataY{1}= lon;
        else   % we need data for location 4:
            datasets=25;
            for data_i = 1:datasets
                load(['Hackathon_data\Hdata_' num2str(data_i)]);
                site(site_data_i).location(loc_data_i).dataX{data_i}=lat;
                site(site_data_i).location(loc_data_i).dataX{2*datasets-data_i+1}=lat;
                site(site_data_i).location(loc_data_i).dataY{data_i}=lon;
                site(site_data_i).location(loc_data_i).dataY{2*datasets-data_i+1}=lon;
            end
        end
    end
end

fig=figure(1);

% h1=subplot(2,2,1);
% h2=subplot(2,2,2);
% h3=subplot(2,2,3);
% h4=subplot(2,2,4);

for time_i=1:2:50
    inputDataImageName = ['Hackathon_data\Hdata_' num2str(time_i) '.png'];
    IN = imread(inputDataImageName);
    for site_i=1:1
        I = imread(site(site_i).image_name);
        for location_i=1:4
            if location_i<=3, input_num=1; else input_num=time_i; end;
            [congestion_status, alarm_color]= assiss_congestion_v2(site(site_i).location(location_i).dataX{input_num}, site(site_i).location(location_i).dataY{input_num});
            if isempty(alarm_color) || isempty(congestion_status), error('empty output from assiss_congestion'); end
            I =insertShape(I, 'FilledCircle', site(site_i).location(location_i).circle, 'color', alarm_color);
            
        end
        
        if site_i==1
            AA=I;
            AIN=IN;
            
        elseif site_i==2
            BB=I;
            BIN=IN;
        end
        
        
    end
    
%     AA=imresize(AA,2.81);
    AA=imresize(AA,1.76);
    [aaa,bbb,ccc]=size(AA);
    AA=[AA(1:890,:,:), zeros(890,20,ccc), AIN(1:890,:,:)];
    imshow(AA)
%     subplot(2,1,1), imshow(AA);
%     subplot(2,1,2), imshow(AIN);
%     subplot(2,2,2), imshow(BB);
%     subplot(2,2,4), imshow(BIN);
    if time_i==1, pause; end;

    pause(0.01);
% figure('units','normalized','outerposition',[0 0 1 1])

end




