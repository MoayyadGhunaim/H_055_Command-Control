
px=[2 5 7 2];

py=[2 5 3 2];

p=[px;py];

mag = (px.^2 + py.^2).^0.5;

% [~,ind]=max(p(2,:));
% ang = tan(p(2,ind)./p(1,ind));

for i=1:size(p,2)
    ang = tan(p(2,i)./p(1,i));
    u(:,i)=[cos(-ang) -sin(-ang) ; sin(-ang)  cos(-ang) ]*p(:,i);
end

plot(p(1,:), p(2,:));
hold on
plot(u(1,:), u(2,:));

xlim([-10 10])
ylim([-10 10])


