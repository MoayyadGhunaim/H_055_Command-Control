

clc
clear all

f=fopen('..\Apr05_v1.csv');
if f<0, error('no file\n'); end;
lat=[];
lon=[];
s=fgetl(f);
while ~feof(f)
    s=fgetl(f);
    ind=find(s=='@');
    x=s(ind(1)+1:ind(2)-1);
    x=str2num(x);
    lat=[lat; x];
    x=s(ind(2)+1:ind(3)-1);
    x=str2num(x);
    lon=[lon; x];
end

clear h;
n=3;
h(1:n)=1/n;

latTmp = lat;
lonTmp = lon;

for i=1:size(lat,2)
    latsm=lat(:,i);
    latsm = conv(latsm, h);
    latsm(1:n-1)=[];
    latsm(end-n-1+1:end)=[];
    lat1(:,i)=latsm;
end

for i=1:size(lon,2)
    lonsm=lon(:,i);
    lonsm = conv(lonsm, h);
    lonsm(1:n-1)=[];
    lonsm(end-n-1+1:end)=[];
    lon1(:,i)=lonsm;
end

lat=lat1;
lon=lon1;

maxLat=max(lat(:));
minLat=min(lat(:));

maxLon=max(lon(:));
minLon=min(lon(:));

% 
% figure(1)
% % subplot(2,1,1), plot(latTmp);
% subplot(2,1,1), plot(lat);
% hold on;
% % subplot(2,1,2), plot(lonTmp);
% subplot(2,1,2), plot(lon);
% hold on;

fig=figure(3);
for t=1:size(lat,1)
    hold off
    for p=1:size(lat,2)
%         if p==4, continue; end;
        h=plot(lon(t,p), lat(t,p) , 'ok', 'linewidth', 1);
        set(h,'MarkerFaceColor','k')
        text(46.6425, 24.7315, num2str(t), 'fontsize', 22, 'fontweight', 'bold');
        text(lon(t,p)-0.0001, lat(t,p)+0.0002, num2str(p));
        xlim([minLon-0.0005 maxLon+0.0005 ]); 
        ylim([minLat-0.0005 maxLat+0.0005 ]);
        hold on;
    end
%     k = waitforbuttonpress; while k~=0; end;
    print(fig, '-dpng', ['..\images\' num2str(t) '.png'])
    
end


