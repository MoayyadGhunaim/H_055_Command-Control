

clc
clear all

% r=0.0010;
r=7;
Ver=2;
customData = 1;
color = zeros(125 , 3);
for countColor1 = 0 : 4
    for countColor2 = 0 : 4
        for countColor3 = 0 : 4
            color(countColor1*25 + countColor2*5 + countColor3 + 1 , :) = [countColor1 countColor2 countColor3];
        end
    end
end
color = color/4;

if customData==6
    load TEST_DATA_01;
    %     r=7;
elseif customData==2
    load TEST_DATA_02;
    %     r=7;
elseif customData==3
    load TEST_DATA_03;
    %     r=7;
elseif customData==4
    load TEST_DATA_04;
    %     r=7;
elseif customData==5
    load TEST_DATA_05;
    %     r=7.6;
elseif customData==6
    load TEST_DATA_06;
    %     r=7;
elseif customData==7
    load TEST_DATA_07;
    %     r=7;
else
end

maxLat=max(lat(:));
minLat=min(lat(:));

maxLon=max(lon(:));
minLon=min(lon(:));

numOfNodes = size(lat,2);

for t=1:size(lat,1)
    
    currentLon = lon(t,:);
    currentLat = lat(t,:);
    
    %%%%%%%%%%%%%%%%%%%%%%% algorithm at time t %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [Labels, groupCount, sizeRank] = clusteringV2(currentLon, currentLat, r);
    [Labels2, groupCount2, sizeRank2] = clusteringV2(currentLon, currentLat, r/2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%% find largest group %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    margin=5;
    
    fig = figure(2);
    ColorCount = 0;
    for p=1:numOfNodes
        GroupColor = color(125,:);
        if groupCount(p) > 1
            ColorCount = ColorCount + 1;
            GroupColor = color(Labels(p),:);
        end
        hh=plot(currentLon(p), currentLat(p) , 'o', 'linewidth', 1, 'color', GroupColor);
        set(hh,'MarkerFaceColor', GroupColor );
        ax=gca;
        ax.Position=[0,0,1,1];
        
        text(currentLon(p)-0.0001, currentLat(p)+0.0002, num2str(Labels(p)));

        xlim([minLon-margin maxLon+margin ]);
        ylim([minLat-margin maxLat+margin ]);
        hold on;
    end
    print(fig, '-dpng', ['..\images\' num2str(t) '_Coarse.png'])
    hold off
    
    fig = figure(3);
    ColorCount = 0;
    for p=1:numOfNodes
        GroupColor = color(125,:);
        if groupCount2(p) > 1
            ColorCount = ColorCount + 1;
            GroupColor = color(Labels2(p),:);
        end
        hh=plot(currentLon(p), currentLat(p) , 'o', 'linewidth', 1, 'color', GroupColor);
        set(hh,'MarkerFaceColor', GroupColor );
        ax=gca;
        ax.Position=[0,0,1,1];
        
        text(currentLon(p)-0.0001, currentLat(p)+0.0002, num2str(Labels2(p)));

        xlim([minLon-margin maxLon+margin ]);
        ylim([minLat-margin maxLat+margin ]);
        hold on;
    end
    print(fig, '-dpng', ['..\images\' num2str(t) '_Fine.png'])
    hold off
    
end


