function Labels = clustering(currentLon, currentLat, distanceThreshold)

% calculate distance matrix:
    numOfNodes = length(currentLon);
    randNode = ceil(rand*numOfNodes);
    distMat = inf(numOfNodes,numOfNodes);
    for i=1:numOfNodes
        for j=1:numOfNodes
            dist = sqrt( (currentLon(i)-currentLon(j))^2 + (currentLat(i)-currentLat(j))^2 );
            if dist <= distanceThreshold
                distMat(i,j) = dist;
            end
        end
    end
    
    %     if t==21
    %         pause(1)
    %     end
    
    G = double(distMat<Inf);        % initialize group matrix to 1s and 0s
    L = zeros(1,numOfNodes);  % initialize labels to 0s
    groupCount=1;
    row=1;
    
    while ~isempty(find(L==0))   % while there is at leat one label equal to 0
        
%         if row==35
%             pause(0.5)
%         end
        
        referenceRow = G(row,:);
        subset = L(logical(referenceRow));
        minLabel = min( subset(subset~=0) );
%         if L(row)==0
        if isempty(minLabel) %|| minLabel==0
            L(row)   = groupCount;
            G(row,:) = referenceRow * L(row);
            groupCount = groupCount + 1;
        else
            L(row) = minLabel;
        end
        label = L(row);
%         label = minLabel;
        
        
        for rr=row+1:numOfNodes  % compare referenceRow with all next rows
            currentRow = G(rr,:);
            p = referenceRow * currentRow';
            if L(rr)==0 && p~=0    % if this row has not been labeled befor AND there is overlap between this row and referenceRow
                G(rr,:) = currentRow*label;
                L(rr) = label;
            end
        end
        row=row+1;
    end
    
    Labels = L;