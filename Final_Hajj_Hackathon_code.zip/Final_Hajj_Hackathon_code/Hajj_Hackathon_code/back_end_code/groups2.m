

clc
clear all

% r=0.0010;
r=7;
Ver=2;
customData = 6;
color = [1 0 0; 0 1 0; 0 0 1; 1 0 1; 0 1 1 ; 1 0.7 0.7; .5 .5 .5; 0.7 0.7 0.7; 1 0.5 0; 0 1 0.5];
blackcolor=zeros(1000,3);
color = [color; blackcolor];
im=imread('map.png');


% n=1:100;

if customData==1
    load TEST_DATA_01;
    %     r=7;
elseif customData==2
    load TEST_DATA_02;
    %     r=7;
elseif customData==3
    load TEST_DATA_03;
    %     r=7;
elseif customData==4
    load TEST_DATA_04;
    %     r=7;
elseif customData==5
    load TEST_DATA_05;
    %     r=7.6;
elseif customData==6
    load TEST_DATA_06;
    %     r=7;
elseif customData==7
    load TEST_DATA_07;
    %     r=7;
else
    r=0.00080;
    f=fopen('..\Apr05_v1.csv');
    if f<0, error('no file\n'); end;
    lat=[];
    lon=[];
    s=fgetl(f);
    while ~feof(f)
        s=fgetl(f);
        ind=find(s=='@');
        x=s(ind(1)+1:ind(2)-1);
        x=str2num(x);
        lat=[lat; x];
        x=s(ind(2)+1:ind(3)-1);
        x=str2num(x);
        lon=[lon; x];
    end
    
    clear h;
    n=3;
    h(1:n)=1/n;
    
    latTmp = lat;
    lonTmp = lon;
    
    for i=1:size(lat,2)
        latsm=lat(:,i);
        latsm = conv(latsm, h);
        latsm(1:n-1)=[];
        latsm(end-n-1+1:end)=[];
        lat1(:,i)=latsm;
    end
    
    for i=1:size(lon,2)
        lonsm=lon(:,i);
        lonsm = conv(lonsm, h);
        lonsm(1:n-1)=[];
        lonsm(end-n-1+1:end)=[];
        lon1(:,i)=lonsm;
    end
    
    lat=lat1;
    lon=lon1;
    
end

maxLat=max(lat(:));
minLat=min(lat(:));

maxLon=max(lon(:));
minLon=min(lon(:));

% if customData==8
%     minLon=(minLon-46)*100;
%      maxLon=(maxLon-46)*100;
%      minLat=(minLat-24)*100;
%      maxLat=(maxLat-24)*100;
% end

fig=figure(3);
numOfNodes = size(lat,2);

for t=1:size(lat,1)
    
    currentLon = lon(t,:);
    currentLat = lat(t,:);
    
    %%%%%%%%%%%%%%%%%%%%%%% algorithm at time t %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if Ver==1
        [Labels, groupCount, sizeRank] = clusteringV1(currentLon, currentLat, r);  % not needed any more
    elseif Ver==2
        [Labels, groupCount, sizeRank] = clusteringV2(currentLon, currentLat, r);
    elseif Ver==3
        [Labels, groupCount, sizeRank] = clusteringColSum(currentLon, currentLat, r);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%% find largest group %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    hold off
    %     if customData==8
    %      hi = imagesc(im);
    %     imshow(im,'InitialMagnification',5)
    %      truesize(gcf,[5 6])
    %      ha = gca;
    %      ha.Position=[0,0,1,1];
    %      ha.Position=[0.1,0.1,.7,.7];
    %      ha.Color='none';
    %      hold on
    
    %      currentLon=(currentLon-46)*100;
    %      currentLat=maxLat-(currentLat-24)*100+minLat;
    %     end
    if customData==8,
        margin=0.0005;
    else
        margin=5;
        
    end
    for p=1:numOfNodes
        %         if p==4, continue; end;
        hh=plot(currentLon(p), currentLat(p) , 'o', 'linewidth', 1, 'color', color( sizeRank(p), : ));
        set(hh,'MarkerFaceColor', color( sizeRank(p), : ) );
        ax=gca;
        ax.Position=[0,0,1,1];
        if customData==8, 
            text(46.6425, 24.7315, ['t = ' (num2str(t-1))], 'fontsize', 18);%, 'fontweight', 'bold'); 
        end
        %         text(currentLon(p)-0.0001, currentLat(p)+0.0002, num2str(p));
%         if customData==8,text(currentLon(p)-0.0001, currentLat(p)+0.0002, num2str(sizeRank(p))); end
        xlim([minLon-margin maxLon+margin ]);
        ylim([minLat-margin maxLat+margin ]);
        hold on;
    end
    if customData==8, k = waitforbuttonpress; while k~=0; end; end
        print(fig, '-dpng', ['..\images\' num2str(t) '.png'])
    pins=unique(sizeRank);
    cnt=zeros(1,length(pins));
    for hhh=1:max(pins)
        cnt(hhh)=sum(sizeRank==pins(hhh));
        fprintf('Cluster#%i = %i nodes\n', pins(hhh), cnt(hhh));
    end
    
    %     figure(2)
    %     bar(pins, cnt);
    
end


