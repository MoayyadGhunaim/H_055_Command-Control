
X=imread(['..\images\maps\haram.bmp']);
Y=imread(['..\images\maps\mina.bmp']);

for i=1:40

    imshow(X)

i
pause(0.5)
end